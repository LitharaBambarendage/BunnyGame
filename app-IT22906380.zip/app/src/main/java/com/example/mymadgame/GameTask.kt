package com.example.mymadgame

interface GameTask {
    fun closeGame(mScore:Int)
}